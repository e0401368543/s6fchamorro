namespace s6fchamorro.Views;

public partial class vEliminar : ContentPage
{
    public vEliminar(Estudiantes datos)
    {
        InitializeComponent();

    }

    private void btnActualizar_Clicked(object sender, EventArgs e)
    {

    }

    private void btnEliminar_Clicked(object sender, EventArgs e)
    {

    }
}