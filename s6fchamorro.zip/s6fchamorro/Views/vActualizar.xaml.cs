namespace s6fchamorro.Views;

public partial class vActualizar : ContentPage
{
	public vActualizar()
	{
		//InitializeComponent();	
	}
}