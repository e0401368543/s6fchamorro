namespace s6fchamorro.Views;

public partial class vAgregar1 : ContentPage
{
	public vAgregar1()
	{
		InitializeComponent();	
	}
}